#############################
## id 341
## Puzzle Elo 821
## Correctly solved 71 %
#############################


cubes = [1, 8, 27]
cubes.append(4 ** 3)
print(cubes)
