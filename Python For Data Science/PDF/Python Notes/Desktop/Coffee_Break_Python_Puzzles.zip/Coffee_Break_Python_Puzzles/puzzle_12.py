#############################
## id 335
## Puzzle Elo 829
## Correctly solved 83 %
#############################


word = "galaxy"
print(word[4:50])