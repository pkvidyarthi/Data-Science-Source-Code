#############################
## id 331
## Puzzle Elo 742
## Correctly solved 63 %
#############################


x = 'silent'
print(x[2] + x[1] + x[0]
      + x[5] + x[3] + x[4])
