#############################
## id 343
## Puzzle Elo 1248
## Correctly solved 47 %
#############################


letters = ['a', 'b', 'c',
           'd', 'e', 'f', 'g']
letters[1:] = []
print(letters)
