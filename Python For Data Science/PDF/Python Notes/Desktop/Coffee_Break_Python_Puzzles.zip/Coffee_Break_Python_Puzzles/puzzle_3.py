#############################
## id 313
## Puzzle Elo 691
## Correctly solved 78 %
#############################


# This is a comment
answer = 42  # the answer

# Now back to the puzzle
text = "# Is this a comment?"
print(text)