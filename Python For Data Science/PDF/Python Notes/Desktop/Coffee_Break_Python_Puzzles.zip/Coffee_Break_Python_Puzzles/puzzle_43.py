#############################
## id 356
## Puzzle Elo 1701
## Correctly solved 40 %
#############################

print("Answer")
while True:
    pass
print("42")
