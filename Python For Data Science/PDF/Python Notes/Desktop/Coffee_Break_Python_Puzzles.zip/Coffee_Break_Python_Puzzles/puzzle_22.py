#############################
## id 342
## Puzzle Elo 1104
## Correctly solved 52 %
#############################


customers = ['Marie', 'Anne', 'Donald']
customers[2:4] = ['Barack', 'Olivia', 'Sophia']
print(customers)

