#############################
## id 327
## Puzzle Elo 786
## Correctly solved 60 %
#############################


print(3 * 'un' + 'ium')
