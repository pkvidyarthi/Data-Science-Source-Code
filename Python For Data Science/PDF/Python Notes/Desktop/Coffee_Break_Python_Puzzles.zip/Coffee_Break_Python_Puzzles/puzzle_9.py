#############################
## id 328
## Puzzle Elo 794
## Correctly solved 74 %
#############################


x = 'py' 'thon'
print(x)
