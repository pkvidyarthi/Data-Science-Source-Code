#############################
## id 348
## Puzzle Elo 858
## Correctly solved 67 %
#############################


words = ['cat', 'mouse']
for word in words:
    print(len(word))
