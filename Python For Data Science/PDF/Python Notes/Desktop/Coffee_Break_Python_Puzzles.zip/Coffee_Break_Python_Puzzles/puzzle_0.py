#############################
## id 321
## Puzzle Elo 527
## Correctly solved 86 %
#############################


print('hello world')