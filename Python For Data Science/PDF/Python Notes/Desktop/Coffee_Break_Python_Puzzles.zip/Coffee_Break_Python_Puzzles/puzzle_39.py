#############################
## id 323
## Puzzle Elo 1629
## Correctly solved 25 %
#############################


print('P"yt\'h"on')
