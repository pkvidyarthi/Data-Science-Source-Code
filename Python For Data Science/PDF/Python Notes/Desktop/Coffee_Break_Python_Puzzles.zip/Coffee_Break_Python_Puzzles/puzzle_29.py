#############################
## id 351
## Puzzle Elo 1346
## Correctly solved 52 %
#############################

print(range(5, 10)[-1])
print(range(0, 10, 3)[2])
print(range(-10, -100, -30)[1])