#############################
## id 367
## Puzzle Elo 1437
## Correctly solved 53 %
#############################

def concatenation(*args, sep="/"):
    return sep.join(args)

print(concatenation("A", "B", "C", sep=","))
