#############################
## id 365
## Puzzle Elo 1005
## Correctly solved 57 %
#############################

def func(a, *args):
    print(a)
    for arg in args:
        print(arg)

func("A", "B", "C")