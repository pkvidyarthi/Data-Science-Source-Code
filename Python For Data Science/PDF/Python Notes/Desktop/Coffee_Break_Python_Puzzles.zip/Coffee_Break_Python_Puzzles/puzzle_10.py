#############################
## id 93
## Puzzle Elo 815
## Correctly solved 76 %
#############################


print(sum(range(0, 7)))
