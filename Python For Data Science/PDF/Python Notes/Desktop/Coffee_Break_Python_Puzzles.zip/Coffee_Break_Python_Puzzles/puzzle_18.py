#############################
## id 334
## Puzzle Elo 954
## Correctly solved 45 %
#############################


word = "galaxy"
print(word[:-2] + word[-2:])
