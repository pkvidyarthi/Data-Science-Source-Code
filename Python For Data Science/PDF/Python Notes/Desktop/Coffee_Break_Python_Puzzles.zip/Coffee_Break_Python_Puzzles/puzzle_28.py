#############################
## id 355
## Puzzle Elo 1311
## Correctly solved 54 %
#############################

for num in range(2, 8):
    if not num % 2:
        continue
    print(num)