#############################
## id 369
## Puzzle Elo 1673
## Correctly solved 30 %
#############################

def func(val1=3, val2=4, val3=6):
    return val1 + val2 + val3

values = {"val1":9, "val3":-1}
print(func(**values))