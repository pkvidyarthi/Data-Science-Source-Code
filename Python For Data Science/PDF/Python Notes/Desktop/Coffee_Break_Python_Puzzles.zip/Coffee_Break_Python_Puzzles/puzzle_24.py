#############################
## id 344
## Puzzle Elo 1211
## Correctly solved 44 %
#############################


letters = ['a', 'b', 'c', 'd']
print(len(letters[1:-1]))
