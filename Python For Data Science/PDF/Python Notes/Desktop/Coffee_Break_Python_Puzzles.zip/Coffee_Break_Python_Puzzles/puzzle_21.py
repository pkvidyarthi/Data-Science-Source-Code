#############################
## id 333
## Puzzle Elo 1038
## Correctly solved 53 %
#############################


word = "bender"
print(word[1:4])
