#############################
## id 358
## Puzzle Elo 899
## Correctly solved 61 %
#############################


def func(x):
    return x + 1

f = func
print(f(2) + func(2))