#############################
## id 337
## Puzzle Elo 745
## Correctly solved 91 %
#############################


squares = [1, 4, 9, 16, 25]
print(squares[0])
