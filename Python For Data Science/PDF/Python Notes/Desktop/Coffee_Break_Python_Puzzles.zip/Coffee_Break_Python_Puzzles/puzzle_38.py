#############################
## id 325
## Puzzle Elo 1623
## Correctly solved 71 %
#############################


print("""
A
B
C
""" == "\nA\nB\nC\n")
