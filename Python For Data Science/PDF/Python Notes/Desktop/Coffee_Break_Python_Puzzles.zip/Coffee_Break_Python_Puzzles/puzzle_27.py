#############################
## id 346
## Puzzle Elo 1300
## Correctly solved 48 %
#############################


# Fibonacci series:
a, b = 0, 1
while b < 5:
    print(b)
    a, b = b, a + b
