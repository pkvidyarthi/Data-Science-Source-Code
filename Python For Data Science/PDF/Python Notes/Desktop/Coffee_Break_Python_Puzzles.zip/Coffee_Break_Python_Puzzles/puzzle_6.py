#############################
## id 336
## Puzzle Elo 778
## Correctly solved 72 %
#############################


word = "galaxy"
print(len(word[1:]))
